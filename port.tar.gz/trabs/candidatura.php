<div class="ap container">

    <h2 class="secao_titulo"><i class="fa fa-angle-right fa-1x"></i>&nbsp;Candidatura</h2>
    <h4>Descrição:</h4>
    <h5 class="trab_texto">
        Sistema de lançamento de candidatura para políticos, feito em 36 horas durante o HackPUC de 2015 em colaboração com 3 amigos da faculdade. A ideia central do sistema era a democratização de campanhas políticas pela internet, dando a opção de candidatos com menor poder econômico criar suas campanhas online com alguns cliques sem precisar pagar ou ter que programar, tendo um site com um domínio tipo "dilma13.candidatura.org". A segunda parte do sistema era voltada ao eleitor no geral, aqui todos os candidatos que lançaram campanha pelo site eram listados, tinhamos opção de busca de candidato por estado e partido e um sistema aonde podia-se avaliar propostas lançadas por candidatos dentro de diversas áreas.    </h5>

    <div class="trab_tecnolgias">
        <h4>Tecnologias usadas:</h4>
        <div class="tech_usd">APACHE2</div>
        <div class="tech_usd">POSTGRESQL</div>
        <div class="tech_usd">PHP</div>
        <div class="tech_usd">CODEIGNITER</div>
        <div class="tech_usd">HTML5</div>
        <div class="tech_usd">CSS3</div>
        <div class="tech_usd">BOOTSTRAP3</div>
        <div class="tech_usd">JQUERY</div>
    </div>
    <div class="trab_imagens">
        <h4>Screenshots</h4>
        <a href="/assets/imgs/hp1.png" target="_blank"><img class="trab_ss" src="/assets/imgs/hp1_t.png"/></a>
        <a href="/assets/imgs/hp2.png" target="_blank"><img class="trab_ss" src="/assets/imgs/hp2_t.png"/></a>
        <a href="/assets/imgs/hp3.png" target="_blank"><img class="trab_ss" src="/assets/imgs/hp3_t.png"/></a>
        <a href="/assets/imgs/hp4.png" target="_blank"><img class="trab_ss" src="/assets/imgs/hp4_t.png"/></a>
        <a href="/assets/imgs/hp5.png" target="_blank"><img class="trab_ss" src="/assets/imgs/hp5_t.png"/></a>
        <a href="/assets/imgs/hp6.png" target="_blank"><img class="trab_ss" src="/assets/imgs/hp6_t.png"/></a>
        <a href="/assets/imgs/hp7.png" target="_blank"><img class="trab_ss" src="/assets/imgs/hp7_t.png"/></a>

    </div>
</div>