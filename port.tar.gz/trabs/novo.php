<div class="ap container">

    <h2 class="secao_titulo"><i class="fa fa-angle-right fa-1x"></i>&nbsp;Precisa de algo?</h2>
    <h4>Me contate!</h4><br>
    <form id="form_contato" class="form-horizontal">
        <div class="form-group">
            <label for="name" class="col-sm-2 control-label">Nome</label>
            <div class="col-sm-10">
                <input type="text" class="form-control" id="name" name="name"value="">
            </div>
        </div>
        <div class="form-group">
            <label for="email" class="col-sm-2 control-label">E-mail</label>
            <div class="col-sm-10">
                <input type="email" class="form-control" id="email" name="email" value="">
            </div>
        </div>
        <div class="form-group">
            <label for="message" class="col-sm-2 control-label">Mensagem</label>
            <div class="col-sm-10">
                <textarea class="form-control" rows="4" name="message" id="message"></textarea>
            </div>
        </div>
        <div class="form-group">
            <label for="human" class="col-sm-2 control-label">2 + 3 = ?</label>
            <div class="col-sm-10">
                <input type="text" class="form-control" id="human" name="human">
            </div>
        </div>
        <div class="form-group">
            <div class="col-sm-10 col-sm-offset-2">
                <input id="enviar_contato" name="submit" type="submit" value="Enviar" class="btn_contato btn btn-primary">
            </div>
        </div>
    </form>
</div>